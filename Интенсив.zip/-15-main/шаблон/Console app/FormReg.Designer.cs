﻿namespace testnes
{
    partial class FormReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtRegLog = new System.Windows.Forms.TextBox();
            this.txtRegPass1 = new System.Windows.Forms.TextBox();
            this.txtRegPass2 = new System.Windows.Forms.TextBox();
            this.btnReg = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtRegLog
            // 
            this.txtRegLog.Location = new System.Drawing.Point(61, 136);
            this.txtRegLog.Name = "txtRegLog";
            this.txtRegLog.Size = new System.Drawing.Size(219, 20);
            this.txtRegLog.TabIndex = 0;
            // 
            // txtRegPass1
            // 
            this.txtRegPass1.Location = new System.Drawing.Point(61, 175);
            this.txtRegPass1.Name = "txtRegPass1";
            this.txtRegPass1.Size = new System.Drawing.Size(219, 20);
            this.txtRegPass1.TabIndex = 1;
            // 
            // txtRegPass2
            // 
            this.txtRegPass2.Location = new System.Drawing.Point(61, 214);
            this.txtRegPass2.Name = "txtRegPass2";
            this.txtRegPass2.Size = new System.Drawing.Size(219, 20);
            this.txtRegPass2.TabIndex = 2;
            // 
            // btnReg
            // 
            this.btnReg.Location = new System.Drawing.Point(61, 257);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(219, 23);
            this.btnReg.TabIndex = 3;
            this.btnReg.Text = "Подтвердить";
            this.btnReg.UseVisualStyleBackColor = true;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(61, 286);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(219, 23);
            this.btnC.TabIndex = 4;
            this.btnC.Text = "У меня уже есть аккаунт";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Введите логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Введите пароль";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Повторите пароль";
            // 
            // FormReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnReg);
            this.Controls.Add(this.txtRegPass2);
            this.Controls.Add(this.txtRegPass1);
            this.Controls.Add(this.txtRegLog);
            this.Name = "FormReg";
            this.Text = "Регистрация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRegLog;
        private System.Windows.Forms.TextBox txtRegPass1;
        private System.Windows.Forms.TextBox txtRegPass2;
        private System.Windows.Forms.Button btnReg;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}