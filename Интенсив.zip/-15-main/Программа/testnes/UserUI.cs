﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testnes
{
   
    public partial class UserUI : Form
    {
        public UserUI()
        {
            InitializeComponent();
            GuestCheck();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            GuestCheck();
        }

        private void GuestCheck()
        {
            if (UserCred.Guest == true)
            {
                btnNonGuest.Enabled = false;
            }
        }

        private void UserUI_Load(object sender, EventArgs e)
        {
            
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
